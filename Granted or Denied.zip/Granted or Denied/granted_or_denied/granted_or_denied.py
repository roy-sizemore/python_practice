'''
Created on Sep 17, 2020

@author: u-vm
'''
# Granted or Denied
# Demonstrates an else clause

print("Welcome to System Security, Inc.")
print("-- where security is our middle name\n")

password = input("Enter your password: ")

if password == "secret":
    print("Access granted")
else:
    print("Access denied")
    
input("\n\nPress Enter to exit")

