'''
Created on Sep 18, 2020

@author: u-vm
'''
# Hero's Inventory 2.0
# Demonstrates tuples

# create inventory and print
inventory = ("Sword",
             "Shield",
             "Armor",
             "Healing Potion")
print("Your items:")
for item in inventory:
    print(item)

#wait for user input to continue
input("\nPress Enter to continue")

#print number of items in inventory
print("You have", len(inventory), "items in your possession.")

input("\nPress Enter to continue")

#test membership using in
if "healing potion" in inventory:
    print("You will live to fight another day")

#display one item through an index
index = int(input("\nEnter the index number of an item in inventory: "))
print("At index", index, "is", inventory[index])

#display slice
start = int(input("\nEnter the index number to begin a slice: "))
finish = int(input("Enter the index number to end the slice: "))
print("inventory[", start, ":", finish, "] is", end=" ")
print(inventory[start:finish])

input("\nPress Enter to continue")

#concatenate two tuples
chest = ("gold", "gems")
print("You find a chest. It constains:")
print(chest)
print("You add the contents of the chest to your inventory.")
inventory += chest
print("Your inventory is now:")
print(inventory)

input("\n\nPress Enter to exit")

 