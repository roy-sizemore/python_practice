'''
Created on Sep 18, 2020

@author: u-vm
'''
# Loopy String
# Demonstrates the for loop w/a string

word = input("Enter a word: ")

print("\nHere's each letter in your word:")
for letter in word:
    print(letter)
    
input("\n\nPress Enter to exit")

