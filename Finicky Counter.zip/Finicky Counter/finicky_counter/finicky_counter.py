'''
Created on Sep 17, 2020

@author: u-vm
'''
# Finicky Counter
# Demonstrates the break and continue statements

count = 0

while True:
    count += 1
    if count > 10:
        break
    if count == 5:
        continue
    print(count)

input("\n\nPress Enter to exit")

