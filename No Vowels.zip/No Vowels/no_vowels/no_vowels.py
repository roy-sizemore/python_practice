'''
Created on Sep 18, 2020

@author: u-vm
'''
# No vowels
# Demonstrates creating new strings w/a for loop (and constant variables)

message = input("Enter a message: ")
new_message = ""
VOWELS = "aeiou"

print()
for letter in message:
    if letter.lower() not in VOWELS:
        new_message += letter
        
        print("Anew string has been created:", new_message)
        
print("\nYour message w/o vowels is:", new_message)

input("\n\nPress Enter to exit")

