'''
Created on Sep 17, 2020

@author: u-vm
'''
# Maitre D'
# Demonstrates treating a value as a condition

print("Welcome t othe Chateau d'Embarkment")
print("It seems we are quite full this evening.\n")

money = int(input("How much money do you slip the Maitre D'? $"))

if money:
    print("Ah, I am reminded of a table. Right this way.")
else:
    print("Please sit. It might be a while.")
    
input("Press Enter to exit")
