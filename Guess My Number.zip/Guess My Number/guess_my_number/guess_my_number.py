'''
Created on Sep 17, 2020

@author: u-vm
'''
# Guess My Number

# The computer picks a random number between 1-100.
# The player tries to guess it and the computer lets 
# the player know if the guess is too high/low/correct.

import random

print("I've selected a number between 1 and 100")
print("Try to guess it in a few tries as possible.\n")

#set the initial values
rand = random.randint(1,100)
guess = int(input("Take a guess: "))
tries = 1

#guessing loop
while guess != rand:
    if guess > rand:
        print("Lower...")
    else:
        print("Higher...")
    guess = int(input("Take a guess: "))
    tries += 1
    
print("\nYou guessed it! The number was: ", rand)
print("And it only took you", tries, "attempts!")

input("\n\nPress Enter to exit")


