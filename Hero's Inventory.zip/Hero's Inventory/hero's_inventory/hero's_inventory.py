'''
Created on Sep 18, 2020

@author: u-vm
'''
# Hero's Inventory
# Demonstrates tuple creation

# create an empty tuple
inventory = ()

# treat the tuple as a condition
if not inventory:
    print("You are empty-handed.")

input("\n\nPress Enter to continue")

# create a tuple w/some items
inventory = ("sword",
             "armor",
             "shield",
             "healing potion")

# print the tuple
print("\nThe hero's inventory is:")
print(inventory)

#print each element in the tuple
print("\nYour items:")
for item in inventory:
    print(item)
    
input("\n\nPress Enter to exit")

