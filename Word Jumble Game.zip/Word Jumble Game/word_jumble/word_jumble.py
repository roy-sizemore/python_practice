'''
Created on Sep 18, 2020

@author: u-vm
'''
# Word Jumble Game
# Demonstrates The computer picks a random word and then "jumbles it.
# The player then has to guess the original word

import random

#setting up the game. Creating a list of words, choosing a random word from the list
#and pulling a letter from the word to add to the jumble
WORDS = ("python",
         "jumble",
         "easy",
         "difficult",
         "answer",
         "xylophone")

word = random.choice(WORDS)
correct = word
jumble = ""

while word:
    position = random.randrange(len(word))
    jumble += word[position]
    word = word[:position] + word[(position + 1):]

#welcoming the player and starting the game
print(
"""
           Welcome to Word Jumble!
        
   Unscramble the letters to make a word.
(Press the enter key at the prompt to quit.)
"""
)
print("The Jumble is:", jumble)

#player's guess
guess = input("\nYour guess: ")
while guess != correct and guess != "":
    print("Sorry, that's not it.")
    guess = input("Your guess: ")
    
#win condition
if guess == correct:
    print("That's it! You guessed it!\n")
    
#ending game
print("Thanks for playing.")

input("\n\nPress Enter to exit")

