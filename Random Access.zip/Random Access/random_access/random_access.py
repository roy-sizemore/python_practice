'''
Created on Sep 18, 2020

@author: u-vm
'''
# Random Access
# Describes string indexing

import random

word = "index"

print("The word is: ", word, "\n")

high = len(word)
low = -len(word)

for i in range(10):
    position = random.randrange(low, high)
    print("word[", position, "]\t", word[position])
    
input("\n\nPress Enter to exit")

